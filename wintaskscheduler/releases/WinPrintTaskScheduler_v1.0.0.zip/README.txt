﻿==================================================
  WinPrintTaskScheduler v1.0.0
  (Windows 자동 프린터 헤드 유지보수 스케줄러)
==================================================

[프로그램 특징]
1. 100% 무의존성 단일 실행파일 (.exe)
2. 다크 모드 (Dark Modern Theme) GUI 지원
3. 백그라운드 무소음(Stealth) 스텔스 인쇄
4. Windows 10/11 Toast 알림 지원

[사용 방법]
1. WinPrintTaskScheduler.exe 파일 실행
2. 대상 프린터 선택 및 스케줄 시간(AM/PM, 시, 분) 지정
3. [Register Task] 버튼 클릭 -> 작업 스케줄러 자동 등록
4. [Test Print Now] 클릭 시 테스트 인쇄 수행

[SmartScreen 경고창 대처]
최초 실행 시 'Windows의 PC 보호' 창이 떠도 안전합니다.
-> [추가 정보] 클릭 -> [실행] 클릭

공개 프로젝트 홈: https://yushare999-tech.github.io/dk-public-projects/wintaskscheduler/
