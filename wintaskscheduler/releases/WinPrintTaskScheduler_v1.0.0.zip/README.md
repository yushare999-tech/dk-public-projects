# 🖨️ WinPrintTaskScheduler (WinForms GUI + Stealth Background Mode)

Windows 환경에서 지정한 스케줄에 따라 프린터로 이미지 및 샘플 페이지 인쇄를 자동 실행해 주는 **100% 무의존성 C# 네이티브 단일 `.exe` 응용 프로그램**입니다.

---

## ✨ 주요 특징
* **100% 무소음/무표시 완전 스텔스 인쇄**: `StandardPrintController` 엔진 적용으로 윈도우 인쇄 진행 다이얼로그 팝업(`"인쇄: document의 1페이지"`)을 화면에서 100% 차단하여 완벽한 백그라운드 인쇄 달성.
* **`TEST_PRINT.bmp` 임베디드 리소스 내장**: 외부 이미지 파일 없이 `TEST_PRINT.bmp` 샘플 이미지가 실행 파일(`.exe`) 내부 바이너리로 영구 내장되어, 실행 시 `%AppData%\WinPrintTaskScheduler\assets\sample_test.bmp`로 자동 추출 생성.
* **Self-Copy 영구 복제 설치**: 다운로드 폴더나 임시 위치의 `.exe`에서 스케줄을 등록하면, 자기 자신(.exe)을 `%AppData%\WinPrintTaskScheduler\` 영구 공간으로 자동 복사 설치하여 **원본 `.exe`가 삭제되어도 365일 영구 동작**.
* **Windows 표준 %AppData% Roaming 데이터 보관**: 모든 설정(`config.json`), 이력(`history.json`), 로그(`app.log`), 이미지 파일(`assets/`)을 사용자 전용 안심 공간(`C:\Users\<계정>\AppData\Roaming\WinPrintTaskScheduler`)에서 관리하여 권한 오류 0%.
* **이미지 자동 내부 안전 복사 보관**: 외부 이미지 선택 시 AppData 영구 폴더로 자동 복사 보관되어 외부 원본 파일이 삭제되어도 문제없음.
* **Windows 10/11 OS 정식 호환성 매니페스트 포함**: 윈도우 프로그램 호환성 관리자(PCA) 경고 팝업 차단 및 High DPI 고해상도 지원.
* **직관적인 시간 선택 UI (AM/PM, 시, 분 드롭다운)**: `[ AM / PM ]`, `[ 01 ~ 12 시 ]`, `[ 00 ~ 59 분 ]` 드롭다운으로 한눈에 지정 가능.
* **더블 클릭 시 환경 설정 GUI 창**: 프로그램 실행 시 프린터 드롭다운 선택, 이미지 파일 브라우저(`Browse...`), 스케줄 시각, 즉시 테스트 인쇄 및 스케줄러 등록/해제 관리 창 제공.

---

## 🚀 사용 모드 및 명령어

### 1. 사용자의 더블 클릭 실행
`WinPrintTaskScheduler.exe`를 더블 클릭하면 **직관적인 환경 설정 GUI 화면(WinForms Window)**이 나타나 모든 설정을 손쉽게 변경할 수 있습니다.

### 2. 스텔스 백그라운드 자동 실행 (스케줄러 호출)
윈도우 스케줄러 등록 시 자동으로 `%AppData%` 영역의 복제본 실행 경로에 `--stealth` 인자가 붙어 화면 표시 없이 100% 백그라운드로 조용히 실행됩니다.

---

## 🛠️ 빌드 방법 (Windows 내장 csc.exe 컴파일러 사용)

Visual Studio나 별도 개발 도구 없이 프로젝트 루트에서 `build.bat`만 실행하면 1초 만에 `WinPrintTaskScheduler.exe`가 컴파일됩니다:

```cmd
build.bat
```

---

## 📂 프로젝트 구조

```
WinPrintTaskScheduler/
├── WinPrintTaskScheduler.exe   # 생성되는 단일 응용 프로그램 (TEST_PRINT.bmp 내장)
├── app.manifest                # Windows OS 호환성 및 High DPI 매니페스트
├── build.bat                   # 윈도우 내장 csc.exe 자동 빌드 스크립트
├── README.md                   # 프로젝트 설명서
├── HISTORY.md                  # 변경 이력
├── assets/
│   └── TEST_PRINT.bmp          # 내장 샘플 리소스 이미지
├── src_cs/                     # C# 네이티브 소스 코드
│   ├── ConfigForm.cs           # WinForms 환경설정 UI 창
│   ├── Program.cs              # 메인 엔트리포인트 & 임베디드 리소스 자동 추출기
│   ├── PrinterManager.cs       # 윈도우 무표시 인쇄 엔진 (StandardPrintController)
│   ├── SchedulerManager.cs     # Self-Copy 설치 및 윈도우 스케줄러 CLI 연동
│   └── Notifier.cs             # Windows Toast 알림 모듈
└── docs/                       # 기술 명세서
    └── PROJECT_INFO.md
```
